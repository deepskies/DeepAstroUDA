# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['deep_astro_uda',
 'deep_astro_uda.client',
 'deep_astro_uda.client.commands',
 'deep_astro_uda.model',
 'deep_astro_uda.utils.']

package_data = \
{'': ['*'], 'deep_astro_uda': ['configs/*']}

install_requires = \
['cleo>=2.0.1,<3.0.0', 'pytest>=7.2.1,<8.0.0', 'torch>=1.13.1,<2.0.0']

setup_kwargs = {
    'name': 'deep-astro-uda',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Ashia Lewis',
    'author_email': 'pantagruelspendulum@protonmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
