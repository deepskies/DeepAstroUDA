import sys

from client.astro_app import main

if __name__ == "__main__":
    sys.exit(main())
